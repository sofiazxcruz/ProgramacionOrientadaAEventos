﻿namespace AdministracionDe_Tareas.Formularios
{
    partial class principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TareasListBox = new System.Windows.Forms.ListBox();
            this.ListaLabel = new System.Windows.Forms.Label();
            this.AgregarTareasGroupBox = new System.Windows.Forms.GroupBox();
            this.AdministrarTareasGroupBox = new System.Windows.Forms.GroupBox();
            this.InformacionGroupBox = new System.Windows.Forms.GroupBox();
            this.EstadoComboBox = new System.Windows.Forms.ComboBox();
            this.EstadoLabel = new System.Windows.Forms.Label();
            this.EditarLabel = new System.Windows.Forms.Label();
            this.EditarTareaTextBox = new System.Windows.Forms.TextBox();
            this.EditarTareaButton = new System.Windows.Forms.Button();
            this.EliminarTareaButton = new System.Windows.Forms.Button();
            this.AgregarTareaTextBox = new System.Windows.Forms.TextBox();
            this.NombreLabel = new System.Windows.Forms.Label();
            this.UsuarioLabel = new System.Windows.Forms.Label();
            this.PosicionLabel = new System.Windows.Forms.Label();
            this.NombreTextBox = new System.Windows.Forms.TextBox();
            this.UsuarioTextBox = new System.Windows.Forms.TextBox();
            this.AgregarInfoButton = new System.Windows.Forms.Button();
            this.PosicionComboBox = new System.Windows.Forms.ComboBox();
            this.AgregarTareaButton = new System.Windows.Forms.Button();
            this.AgregarTareasGroupBox.SuspendLayout();
            this.AdministrarTareasGroupBox.SuspendLayout();
            this.InformacionGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // TareasListBox
            // 
            this.TareasListBox.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TareasListBox.FormattingEnabled = true;
            this.TareasListBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.TareasListBox.ItemHeight = 20;
            this.TareasListBox.Items.AddRange(new object[] {
            "Gestión de proyectos.",
            "Atención al cliente.",
            "Contabilidad y Finanzas.",
            "Recursos Humanos.",
            "Marketing y Publicidad.",
            "Desarrollo de Productos.",
            "Gestion de Operaciones."});
            this.TareasListBox.Location = new System.Drawing.Point(18, 59);
            this.TareasListBox.Name = "TareasListBox";
            this.TareasListBox.Size = new System.Drawing.Size(191, 264);
            this.TareasListBox.TabIndex = 0;
            // 
            // ListaLabel
            // 
            this.ListaLabel.AutoSize = true;
            this.ListaLabel.Font = new System.Drawing.Font("Segoe UI Black", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListaLabel.Location = new System.Drawing.Point(13, 31);
            this.ListaLabel.Name = "ListaLabel";
            this.ListaLabel.Size = new System.Drawing.Size(196, 25);
            this.ListaLabel.TabIndex = 1;
            this.ListaLabel.Text = "LISTADO DE TAREAS";
            // 
            // AgregarTareasGroupBox
            // 
            this.AgregarTareasGroupBox.Controls.Add(this.AgregarTareaButton);
            this.AgregarTareasGroupBox.Controls.Add(this.AgregarTareaTextBox);
            this.AgregarTareasGroupBox.Font = new System.Drawing.Font("Segoe UI Black", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgregarTareasGroupBox.Location = new System.Drawing.Point(232, 31);
            this.AgregarTareasGroupBox.Name = "AgregarTareasGroupBox";
            this.AgregarTareasGroupBox.Size = new System.Drawing.Size(265, 202);
            this.AgregarTareasGroupBox.TabIndex = 2;
            this.AgregarTareasGroupBox.TabStop = false;
            this.AgregarTareasGroupBox.Text = "        AGREGAR TAREAS";
            // 
            // AdministrarTareasGroupBox
            // 
            this.AdministrarTareasGroupBox.Controls.Add(this.EliminarTareaButton);
            this.AdministrarTareasGroupBox.Controls.Add(this.EditarTareaButton);
            this.AdministrarTareasGroupBox.Controls.Add(this.EditarTareaTextBox);
            this.AdministrarTareasGroupBox.Controls.Add(this.EditarLabel);
            this.AdministrarTareasGroupBox.Font = new System.Drawing.Font("Segoe UI Black", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdministrarTareasGroupBox.Location = new System.Drawing.Point(232, 262);
            this.AdministrarTareasGroupBox.Name = "AdministrarTareasGroupBox";
            this.AdministrarTareasGroupBox.Size = new System.Drawing.Size(265, 268);
            this.AdministrarTareasGroupBox.TabIndex = 3;
            this.AdministrarTareasGroupBox.TabStop = false;
            this.AdministrarTareasGroupBox.Text = "ADMINISTRAR TAREAS";
            // 
            // InformacionGroupBox
            // 
            this.InformacionGroupBox.Controls.Add(this.PosicionComboBox);
            this.InformacionGroupBox.Controls.Add(this.EstadoComboBox);
            this.InformacionGroupBox.Controls.Add(this.EstadoLabel);
            this.InformacionGroupBox.Controls.Add(this.AgregarInfoButton);
            this.InformacionGroupBox.Controls.Add(this.UsuarioTextBox);
            this.InformacionGroupBox.Controls.Add(this.NombreTextBox);
            this.InformacionGroupBox.Controls.Add(this.PosicionLabel);
            this.InformacionGroupBox.Controls.Add(this.UsuarioLabel);
            this.InformacionGroupBox.Controls.Add(this.NombreLabel);
            this.InformacionGroupBox.Font = new System.Drawing.Font("Segoe UI Black", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InformacionGroupBox.Location = new System.Drawing.Point(609, 31);
            this.InformacionGroupBox.Name = "InformacionGroupBox";
            this.InformacionGroupBox.Size = new System.Drawing.Size(304, 535);
            this.InformacionGroupBox.TabIndex = 5;
            this.InformacionGroupBox.TabStop = false;
            this.InformacionGroupBox.Text = "INFORMACION DEL USUARIO";
            // 
            // EstadoComboBox
            // 
            this.EstadoComboBox.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EstadoComboBox.FormattingEnabled = true;
            this.EstadoComboBox.Location = new System.Drawing.Point(40, 395);
            this.EstadoComboBox.Name = "EstadoComboBox";
            this.EstadoComboBox.Size = new System.Drawing.Size(209, 28);
            this.EstadoComboBox.TabIndex = 0;
            // 
            // EstadoLabel
            // 
            this.EstadoLabel.AutoSize = true;
            this.EstadoLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EstadoLabel.Location = new System.Drawing.Point(26, 352);
            this.EstadoLabel.Name = "EstadoLabel";
            this.EstadoLabel.Size = new System.Drawing.Size(250, 23);
            this.EstadoLabel.TabIndex = 1;
            this.EstadoLabel.Text = "Seleccione el estado de la tarea";
            // 
            // EditarLabel
            // 
            this.EditarLabel.AutoSize = true;
            this.EditarLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditarLabel.Location = new System.Drawing.Point(40, 42);
            this.EditarLabel.Name = "EditarLabel";
            this.EditarLabel.Size = new System.Drawing.Size(192, 46);
            this.EditarLabel.TabIndex = 0;
            this.EditarLabel.Text = "Seleccionar la tarea que\r\n        desea editar";
            // 
            // EditarTareaTextBox
            // 
            this.EditarTareaTextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditarTareaTextBox.Location = new System.Drawing.Point(20, 112);
            this.EditarTareaTextBox.Name = "EditarTareaTextBox";
            this.EditarTareaTextBox.Size = new System.Drawing.Size(220, 27);
            this.EditarTareaTextBox.TabIndex = 1;
            // 
            // EditarTareaButton
            // 
            this.EditarTareaButton.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditarTareaButton.Location = new System.Drawing.Point(57, 160);
            this.EditarTareaButton.Name = "EditarTareaButton";
            this.EditarTareaButton.Size = new System.Drawing.Size(146, 37);
            this.EditarTareaButton.TabIndex = 2;
            this.EditarTareaButton.Text = "EDITAR TAREA";
            this.EditarTareaButton.UseVisualStyleBackColor = true;
            this.EditarTareaButton.Click += new System.EventHandler(this.EditarTareaButton_Click);
            // 
            // EliminarTareaButton
            // 
            this.EliminarTareaButton.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EliminarTareaButton.Location = new System.Drawing.Point(57, 217);
            this.EliminarTareaButton.Name = "EliminarTareaButton";
            this.EliminarTareaButton.Size = new System.Drawing.Size(146, 37);
            this.EliminarTareaButton.TabIndex = 3;
            this.EliminarTareaButton.Text = "ELIMINAR TAREA";
            this.EliminarTareaButton.UseVisualStyleBackColor = true;
            this.EliminarTareaButton.Click += new System.EventHandler(this.EliminarTareaButton_Click);
            // 
            // AgregarTareaTextBox
            // 
            this.AgregarTareaTextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgregarTareaTextBox.Location = new System.Drawing.Point(28, 71);
            this.AgregarTareaTextBox.Name = "AgregarTareaTextBox";
            this.AgregarTareaTextBox.Size = new System.Drawing.Size(212, 27);
            this.AgregarTareaTextBox.TabIndex = 0;
            // 
            // NombreLabel
            // 
            this.NombreLabel.AutoSize = true;
            this.NombreLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NombreLabel.Location = new System.Drawing.Point(112, 42);
            this.NombreLabel.Name = "NombreLabel";
            this.NombreLabel.Size = new System.Drawing.Size(73, 23);
            this.NombreLabel.TabIndex = 0;
            this.NombreLabel.Text = "Nombre";
            // 
            // UsuarioLabel
            // 
            this.UsuarioLabel.AutoSize = true;
            this.UsuarioLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsuarioLabel.Location = new System.Drawing.Point(117, 147);
            this.UsuarioLabel.Name = "UsuarioLabel";
            this.UsuarioLabel.Size = new System.Drawing.Size(68, 23);
            this.UsuarioLabel.TabIndex = 1;
            this.UsuarioLabel.Text = "Usuario";
            // 
            // PosicionLabel
            // 
            this.PosicionLabel.AutoSize = true;
            this.PosicionLabel.Font = new System.Drawing.Font("Segoe UI Semibold", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PosicionLabel.Location = new System.Drawing.Point(70, 245);
            this.PosicionLabel.Name = "PosicionLabel";
            this.PosicionLabel.Size = new System.Drawing.Size(155, 23);
            this.PosicionLabel.TabIndex = 2;
            this.PosicionLabel.Text = "Posicion de trabajo";
            // 
            // NombreTextBox
            // 
            this.NombreTextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NombreTextBox.Location = new System.Drawing.Point(40, 97);
            this.NombreTextBox.Name = "NombreTextBox";
            this.NombreTextBox.Size = new System.Drawing.Size(209, 27);
            this.NombreTextBox.TabIndex = 3;
            // 
            // UsuarioTextBox
            // 
            this.UsuarioTextBox.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UsuarioTextBox.Location = new System.Drawing.Point(40, 191);
            this.UsuarioTextBox.Name = "UsuarioTextBox";
            this.UsuarioTextBox.Size = new System.Drawing.Size(209, 27);
            this.UsuarioTextBox.TabIndex = 4;
            // 
            // AgregarInfoButton
            // 
            this.AgregarInfoButton.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgregarInfoButton.Location = new System.Drawing.Point(74, 462);
            this.AgregarInfoButton.Name = "AgregarInfoButton";
            this.AgregarInfoButton.Size = new System.Drawing.Size(151, 37);
            this.AgregarInfoButton.TabIndex = 6;
            this.AgregarInfoButton.Text = "AGREGAR";
            this.AgregarInfoButton.UseVisualStyleBackColor = true;
            this.AgregarInfoButton.Click += new System.EventHandler(this.AgregarInfoButton_Click);
            // 
            // PosicionComboBox
            // 
            this.PosicionComboBox.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PosicionComboBox.FormattingEnabled = true;
            this.PosicionComboBox.Location = new System.Drawing.Point(40, 294);
            this.PosicionComboBox.Name = "PosicionComboBox";
            this.PosicionComboBox.Size = new System.Drawing.Size(209, 28);
            this.PosicionComboBox.TabIndex = 7;
            // 
            // AgregarTareaButton
            // 
            this.AgregarTareaButton.Font = new System.Drawing.Font("Segoe UI Black", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgregarTareaButton.Location = new System.Drawing.Point(57, 147);
            this.AgregarTareaButton.Name = "AgregarTareaButton";
            this.AgregarTareaButton.Size = new System.Drawing.Size(146, 35);
            this.AgregarTareaButton.TabIndex = 1;
            this.AgregarTareaButton.Text = "AGREGAR TAREA";
            this.AgregarTareaButton.UseVisualStyleBackColor = true;
            this.AgregarTareaButton.Click += new System.EventHandler(this.AgregarTareaButton_Click);
            // 
            // principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 708);
            this.Controls.Add(this.InformacionGroupBox);
            this.Controls.Add(this.AdministrarTareasGroupBox);
            this.Controls.Add(this.AgregarTareasGroupBox);
            this.Controls.Add(this.ListaLabel);
            this.Controls.Add(this.TareasListBox);
            this.Name = "principal";
            this.Text = "principal";
            this.AgregarTareasGroupBox.ResumeLayout(false);
            this.AgregarTareasGroupBox.PerformLayout();
            this.AdministrarTareasGroupBox.ResumeLayout(false);
            this.AdministrarTareasGroupBox.PerformLayout();
            this.InformacionGroupBox.ResumeLayout(false);
            this.InformacionGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox TareasListBox;
        private System.Windows.Forms.Label ListaLabel;
        private System.Windows.Forms.GroupBox AgregarTareasGroupBox;
        private System.Windows.Forms.GroupBox AdministrarTareasGroupBox;
        private System.Windows.Forms.GroupBox InformacionGroupBox;
        private System.Windows.Forms.Label EstadoLabel;
        private System.Windows.Forms.ComboBox EstadoComboBox;
        private System.Windows.Forms.Label EditarLabel;
        private System.Windows.Forms.TextBox AgregarTareaTextBox;
        private System.Windows.Forms.Button EliminarTareaButton;
        private System.Windows.Forms.Button EditarTareaButton;
        private System.Windows.Forms.TextBox EditarTareaTextBox;
        private System.Windows.Forms.Label PosicionLabel;
        private System.Windows.Forms.Label UsuarioLabel;
        private System.Windows.Forms.Label NombreLabel;
        private System.Windows.Forms.Button AgregarInfoButton;
        private System.Windows.Forms.TextBox UsuarioTextBox;
        private System.Windows.Forms.TextBox NombreTextBox;
        private System.Windows.Forms.ComboBox PosicionComboBox;
        private System.Windows.Forms.Button AgregarTareaButton;
    }
}