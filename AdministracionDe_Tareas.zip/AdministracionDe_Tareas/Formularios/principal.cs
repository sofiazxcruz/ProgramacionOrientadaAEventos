﻿using BibliotecaClases;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdministracionDe_Tareas.Formularios
{
    public partial class principal : Form
    {
        public principal()
        {
            InitializeComponent();
            InitializeEstadoCombobox();
            InitializePosicionComboBox();
        }

        private void InitializePosicionComboBox()
        {
            PosicionComboBox.Items.AddRange(Enum.GetNames(typeof(BibliotecaClases.Enums.PosicionDeTrabajo)));
            
        }

        private void InitializeEstadoCombobox()
        {
            EstadoComboBox.Items.AddRange(Enum.GetNames(typeof(BibliotecaClases.Enums.EstadoDeLasTareas)));
              
        }

        private void EditarTareaButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(EditarTareaTextBox.Text) || string.IsNullOrWhiteSpace(EditarTareaTextBox.Text))
            {
                return;
            }
            int indice = TareasListBox.SelectedIndex;
            if (indice >= 0 && indice < TareasListBox.Items.Count)
            {
                TareasListBox.Items[indice] = EditarTareaTextBox.Text;
            }
            
        }

        private void EliminarTareaButton_Click(object sender, EventArgs e)
        {
            TareasListBox.Items.Remove(TareasListBox.SelectedItem);
        }

        private void AgregarInfoButton_Click(object sender, EventArgs e)
        {
            Usuario usuario = new Usuario();

            usuario.Nombre = NombreTextBox.Text;
            usuario.Username = UsuarioTextBox.Text;
            usuario.Posicion =(BibliotecaClases.Enums.PosicionDeTrabajo)PosicionComboBox.SelectedIndex;
            usuario.Status = (BibliotecaClases.Enums.EstadoDeLasTareas)EstadoComboBox.SelectedIndex;

            MessageBox.Show($"Nombre: {usuario.Nombre}" +
                $";\nUsername: {usuario.Username} " +
                $";\nPosicion: {usuario.Posicion} " +
                $";\nEstado: {usuario.Status}. ");
        }

        private void AgregarTareaButton_Click(object sender, EventArgs e)
        {
            TareasListBox.Items.Add(AgregarTareaTextBox.Text);
        }
    }
}
